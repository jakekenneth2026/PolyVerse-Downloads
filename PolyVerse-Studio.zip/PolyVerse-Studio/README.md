# PolyVerse Studio — first version

A local, single-player game builder using the project's existing Three.js WebGL engine. There is no new paid engine service or cloud dependency.

## Open it

After deploying the website files, choose **Studio** in the website sidebar, or open:

`https://polyverse.wasmer.app/studio/index.html`

The direct static URL does not need a working Laravel database. `/studio` also redirects there when Laravel is working.

For the downloadable standalone copy, extract the ZIP and open `index.html` in a current desktop browser with WebGL/hardware acceleration. All engine scripts are included. If a browser restricts storage on local files, open the deployed site or use Export game; do not disable browser security.

## Build your first game

1. Start with **Blue Sky Obby**, or choose New → Empty baseplate.
2. Insert a block, sphere, cylinder, wedge or spawn pad with **+ Part**.
3. Select it in Explorer or the scene. Drag to move across the horizontal plane, or use Properties for exact X/Y/Z positions. Select Rotate or Scale to change the drag tool. Mouse-wheel zooms; right-drag orbits; F focuses on the selection.
4. Check/uncheck **Studs** to add/remove cosmetic studs on blocks and spawn pads. Studs do not change collision bounds.
5. Adjust color, size, rotation, Anchored, Can collide, and Touch action. Touch actions provide bounce pads, checkpoints, goals, and player-reset hazards.
6. Use **Play**. WASD/arrow keys walk, Shift runs, Space jumps, and right-drag controls the follow camera. The character moves and its arms/legs animate. **Stop** or Escape returns to the original editor scene.
7. **Save** saves to this browser/app on this device. **Export game** downloads a `.polyverse.json` project file. Keep an export as a separate backup. **Open file** imports a project.

Changes autosave locally after a short delay if browser storage is available. This is not cloud saving, and clearing browser/app data can remove local projects. Browser and desktop app storage are separate. Export/import moves projects between devices and apps.

## Plugins

The Plugins panel includes stairs, a block tree, a gateway and a bounce pad. Imported `.polyplugin.json` files are bounded, declarative prefabs. They can add at most 100 parts and use the built-in touch actions. Scripts, external URLs and arbitrary executable code are not part of the plugin format and are discarded. `Stair-builder.polyplugin.json` in the download demonstrates the format.

## Limits

This first version supports 500 parts and a capped number of cosmetic studs. Collision uses axis-aligned bounding boxes, including for rotated blocks, spheres and wedges; it is an approximate prototype physics system. Unanchored parts fall vertically and land on anchored surfaces. There are no rigid-body joints, scripted NPCs, multiplayer servers, public publishing, arbitrary game scripting, plugin marketplace, or Roblox file compatibility.

Projects and exports contain game data only. Play changes a separate simulation scene, and Stop rebuilds from the original project. No executable project/plugin code, system shell access, account changes or payment operations are used by Studio.

## Verification

From the repository root:

```sh
node --test tests/studio/core.test.cjs tests/studio/editor.test.cjs
```

The core tests cover validation, collision, jumping, normalized movement, bounce pads and animation. The editor tests run the real editor script with a mocked graphics renderer and verify Explorer editing, studs, prefabs, undo, local persistence, Play movement/animation/physics and Stop restoration.

An initial real WebGL run rendered the editor and confirmed character movement. Its leg-animation assertion sampled the character as it left the spawn pad and failed. The animation was then changed to continue in the air, and the deterministic editor/physics tests pass. A full graphics retest was blocked by automatic approval review's usage limit, so the corrected Play visuals and final rendered behavior have not been fully reverified. `tests/studio/runtime.cjs` is the pending graphics test; it uses the already installed desktop Electron runtime and a local test server.
