(() => {
    'use strict';
    const C = window.PolyverseStudioCore;
    const $ = id => document.getElementById(id);
    const STORAGE = 'polyverse.studio.project.v1';
    const viewport = $('viewport');
    let renderer;
    try { renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false }); }
    catch (_) { $('viewportError').hidden = false; $('viewportError').textContent = 'Studio needs WebGL graphics. Enable hardware acceleration or try a current desktop browser.'; return; }
    renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 2));
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    viewport.prepend(renderer.domElement);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 2000);
    camera.position.set(35, 28, 40);
    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 2, 0);
    controls.enableDamping = true; controls.dampingFactor = .12;
    controls.mouseButtons = { LEFT: null, MIDDLE: THREE.MOUSE.PAN, RIGHT: THREE.MOUSE.ROTATE };
    scene.add(new THREE.HemisphereLight(0xffffff, 0x7b8799, .85));
    const sun = new THREE.DirectionalLight(0xffffff, .9);
    sun.position.set(30, 60, 25); sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.camera.left = -65; sun.shadow.camera.right = 65; sun.shadow.camera.top = 65; sun.shadow.camera.bottom = -65;
    sun.shadow.bias = -.001; scene.add(sun);
    const grid = new THREE.GridHelper(128, 64, 0x456781, 0x718b99);
    grid.position.y = .012; scene.add(grid);
    const world = new THREE.Group(); scene.add(world);
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    const plane = new THREE.Plane();
    const hitPoint = new THREE.Vector3();
    const selectionBox = new THREE.BoxHelper(new THREE.Object3D(), 0x007bff);
    selectionBox.visible = false; scene.add(selectionBox);
    const geometries = {
        block: new THREE.BoxBufferGeometry(1, 1, 1), sphere: new THREE.SphereBufferGeometry(.5, 24, 16),
        cylinder: new THREE.CylinderBufferGeometry(.5, .5, 1, 24), spawn: new THREE.BoxBufferGeometry(1, 1, 1)
    };
    const wedge = new THREE.Shape(); wedge.moveTo(-.5, -.5); wedge.lineTo(.5, -.5); wedge.lineTo(.5, .5); wedge.closePath();
    geometries.wedge = new THREE.ExtrudeBufferGeometry(wedge, { depth: 1, bevelEnabled: false }); geometries.wedge.translate(0, 0, -.5);
    const studGeometry = new THREE.CylinderBufferGeometry(.17, .17, .12, 10);
    let project = C.starter(), selectedId = null, mode = 'move', playing = false, dirty = false;
    let objects = new Map(), undo = [], redo = [], drag = null, saveTimer;
    let player = null, avatar = null, spawn = [0, .5, 14], checkpoint = spawn.slice();
    let cameraYaw = .3, cameraPitch = .25, playLook = null, editorCamera, runtimeBodies = [];
    const keys = new Set();
    let logs = ['Studio ready. Your starter game is ready to play.'];
    function log(message) { logs.unshift(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + '  ' + message); logs = logs.slice(0, 10); $('outputLog').textContent = logs.join('\n'); }
    function remember() { undo.push(JSON.stringify(project)); if (undo.length > 60) undo.shift(); redo = []; }
    function changed(message) {
        dirty = true; $('saveStatus').textContent = 'Unsaved on this device';
        $('projectName').value = project.name; $('status').textContent = project.name;
        clearTimeout(saveTimer); saveTimer = setTimeout(() => save(false), 600);
        if (message) log(message);
    }
    function save(explicit = true) {
        if (playing) return;
        try { localStorage.setItem(STORAGE, JSON.stringify(project)); dirty = false; $('saveStatus').textContent = 'Saved on this device'; if (explicit) log('Project saved on this device. Export for a separate backup.'); }
        catch (_) { $('saveStatus').textContent = 'Not saved — export a file'; log('Local storage is unavailable or full. Use Export game to keep your work.'); }
    }
    function disposeWorld() {
        world.children.slice().forEach(group => { group.traverse(obj => { if (obj.material) [].concat(obj.material).forEach(mat => mat.dispose()); }); world.remove(group); });
        objects.clear();
    }
    function buildPart(data, studBudget) {
        const group = new THREE.Group(); group.name = data.name; group.userData.partId = data.id;
        group.position.fromArray(data.position); group.rotation.set(...data.rotation.map(n => n * Math.PI / 180));
        const material = new THREE.MeshStandardMaterial({ color: data.color, roughness: .74 });
        const mesh = new THREE.Mesh(geometries[data.shape], material);
        mesh.scale.fromArray(data.size); mesh.castShadow = true; mesh.receiveShadow = true; mesh.userData.partId = data.id;
        group.add(mesh); group.userData.base = mesh;
        if (data.studs && ['block', 'spawn'].includes(data.shape) && studBudget.count > 0) {
            let nx = Math.min(24, Math.max(1, Math.floor(data.size[0] / 1.1)));
            let nz = Math.min(24, Math.max(1, Math.floor(data.size[2] / 1.1)));
            while (nx * nz > Math.min(576, studBudget.count)) { if (nx >= nz) nx--; else nz--; }
            const count = nx * nz;
            if (count > 0) {
                const studs = new THREE.InstancedMesh(studGeometry, material.clone(), count);
                const matrix = new THREE.Matrix4(); let i = 0;
                for (let x = 0; x < nx; x++) for (let z = 0; z < nz; z++) {
                    matrix.makeTranslation((x + .5) * data.size[0] / nx - data.size[0] / 2, data.size[1] / 2 + .06, (z + .5) * data.size[2] / nz - data.size[2] / 2);
                    studs.setMatrixAt(i++, matrix);
                }
                studs.instanceMatrix.needsUpdate = true; studs.userData.partId = data.id; studs.receiveShadow = true; group.add(studs); studBudget.count -= count;
            }
        }
        if (data.shape === 'spawn') {
            const marker = new THREE.Mesh(new THREE.CylinderBufferGeometry(.8, .8, .025, 24), new THREE.MeshBasicMaterial({ color: '#007bff' }));
            marker.position.y = data.size[1] / 2 + .025; group.add(marker);
        }
        world.add(group); objects.set(data.id, group); return group;
    }
    function rebuild() {
        disposeWorld(); const budget = { count: 12000 };
        project.parts.forEach(part => buildPart(part, budget));
        scene.background = new THREE.Color(project.sky); scene.fog = new THREE.Fog(project.sky, 110, 400);
        $('skyColor').value = project.sky; $('projectName').value = project.name; $('status').textContent = project.name;
        world.updateMatrixWorld(true); updateExplorer(); updateProperties();
    }
    function updateExplorer() {
        const fragment = document.createDocumentFragment();
        for (const part of project.parts) {
            const row = document.createElement('div'); row.className = 'tree-item' + (part.id === selectedId ? ' selected' : '');
            row.setAttribute('role', 'listitem'); row.tabIndex = 0; row.dataset.id = part.id;
            const icon = document.createElement('span'); icon.className = 'part-icon'; icon.style.background = part.color;
            const name = document.createElement('span'); name.textContent = part.name;
            row.append(icon, name); row.onclick = () => select(part.id); row.onkeydown = event => { if (event.key === 'Enter') select(part.id); };
            fragment.append(row);
        }
        $('explorer').replaceChildren(fragment); $('partCount').textContent = project.parts.length + ' / 500';
    }
    const selected = () => project.parts.find(part => part.id === selectedId);
    function select(id) { if (playing) return; selectedId = id; updateExplorer(); updateProperties(); }
    function updateProperties() {
        const part = selected(); $('properties').hidden = !part; $('noSelection').hidden = !!part;
        $('duplicate').disabled = $('deletePart').disabled = !part || playing;
        selectionBox.visible = !!part && !playing;
        if (!part) { $('selectionLabel').textContent = 'Select a part to start building'; return; }
        selectionBox.setFromObject(objects.get(part.id));
        $('partName').value = part.name; $('partColor').value = part.color;
        document.querySelectorAll('[data-field]').forEach(input => input.value = part[input.dataset.field][+input.dataset.axis]);
        $('partStuds').checked = part.studs; $('defaultStuds').checked = part.studs;
        $('partAnchored').checked = part.anchored; $('partCollidable').checked = part.collidable; $('partBehavior').value = part.behavior;
        $('selectionLabel').textContent = part.name + ' · ' + mode + ' · drag to edit';
    }
    function edit(mutator, message) { if (playing || !selected()) return; remember(); mutator(selected()); project = C.validate(project); rebuild(); changed(message); }
    function addParts(parts, message) {
        if (playing) return;
        if (project.parts.length + parts.length > C.MAX_PARTS) { log('Part limit reached. This version supports 500 parts.'); return; }
        remember(); const clean = parts.map(part => C.part({ ...part, id: C.uid() })); project.parts.push(...clean); selectedId = clean[0]?.id || null; rebuild(); changed(message);
    }
    function targetPosition() { return [Math.round(controls.target.x), Math.max(1, Math.round(controls.target.y)), Math.round(controls.target.z)]; }
    function focus() { const part = selected(); if (!part || playing) return; controls.target.fromArray(part.position); camera.position.copy(controls.target).add(new THREE.Vector3(10, 9, 12)); controls.update(); }
    function download(name, text) {
        const url = URL.createObjectURL(new Blob([text], { type: 'application/json' })); const link = document.createElement('a'); link.href = url; link.download = name; document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
    function applyProject(next) { if (playing) stop(); clearTimeout(saveTimer); remember(); project = C.validate(next); selectedId = null; rebuild(); changed('Project opened.'); }
    $('addPart').onclick = () => addParts([{ name: $('partShape').selectedOptions[0].text, shape: $('partShape').value, position: targetPosition(), size: $('partShape').value === 'spawn' ? [6, .3, 6] : [4, 1, 4], studs: $('defaultStuds').checked, color: '#2586ed' }], 'Part inserted.');
    $('duplicate').onclick = () => { const part = selected(); if (part) addParts([{ ...part, name: part.name + ' copy', position: [part.position[0] + 4, part.position[1], part.position[2]] }], 'Part duplicated.'); };
    $('deletePart').onclick = () => { if (!selected() || playing) return; remember(); project.parts = project.parts.filter(part => part.id !== selectedId); selectedId = null; rebuild(); changed('Part deleted.'); };
    $('undo').onclick = () => { if (playing || !undo.length) return; redo.push(JSON.stringify(project)); project = C.validate(JSON.parse(undo.pop())); selectedId = null; rebuild(); changed(); };
    $('redo').onclick = () => { if (playing || !redo.length) return; undo.push(JSON.stringify(project)); project = C.validate(JSON.parse(redo.pop())); selectedId = null; rebuild(); changed(); };
    document.querySelectorAll('[data-mode]').forEach(button => button.onclick = () => { mode = button.dataset.mode; document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('active', b === button)); updateProperties(); });
    $('properties').onsubmit = event => event.preventDefault();
    $('partName').onchange = () => edit(part => part.name = $('partName').value, 'Part renamed.');
    $('partColor').onchange = () => edit(part => part.color = $('partColor').value);
    document.querySelectorAll('[data-field]').forEach(input => input.onchange = () => edit(part => part[input.dataset.field][+input.dataset.axis] = Number(input.value)));
    for (const [id, field] of [['partStuds', 'studs'], ['partAnchored', 'anchored'], ['partCollidable', 'collidable']]) $(id).onchange = () => edit(part => part[field] = $(id).checked);
    $('defaultStuds').onchange = () => { if (selected()) edit(part => part.studs = $('defaultStuds').checked); };
    $('partBehavior').onchange = () => edit(part => part.behavior = $('partBehavior').value);
    $('skyColor').onchange = () => { if (playing) return; remember(); project.sky = $('skyColor').value; scene.background.set(project.sky); scene.fog.color.set(project.sky); changed(); };
    $('focusSelection').onclick = focus;
    $('saveProject').onclick = () => save();
    $('exportProject').onclick = () => download(project.name.replace(/[^a-z0-9-]/gi, '-').slice(0, 60) + '.polyverse.json', JSON.stringify(project, null, 2));
    $('projectName').onchange = () => { remember(); project.name = $('projectName').value.trim() || 'Untitled game'; changed(); };
    $('openProject').onclick = () => $('projectFile').click();
    $('projectFile').onchange = async () => {
        const file = $('projectFile').files[0]; if (!file) return;
        try { if (file.size > 2 * 1024 * 1024) throw new Error('Choose a project under 2 MB.'); applyProject(C.validate(JSON.parse(await file.text()))); }
        catch (error) { log('Open failed: ' + error.message); }
        $('projectFile').value = '';
    };
    document.querySelectorAll('[data-close]').forEach(button => button.onclick = () => $(button.dataset.close).close());
    $('helpButton').onclick = () => $('helpDialog').showModal(); $('newProject').onclick = () => $('newDialog').showModal(); $('plugins').onclick = () => $('pluginDialog').showModal();
    $('newObby').onclick = () => { applyProject(C.starter()); $('newDialog').close(); };
    $('newBaseplate').onclick = () => { const next = C.empty(); next.name = 'My new game'; next.parts = C.starter().parts.slice(0, 2); applyProject(next); $('newDialog').close(); };
    const prefabs = {
        stairs: () => Array.from({ length: 8 }, (_, i) => ({ name: 'Step ' + (i + 1), position: [0, (i + 1) / 2, -i * 2], size: [6, i + 1, 2], color: '#6b9ed9', studs: true })),
        tree: () => [{ name: 'Tree trunk', position: [0, 3, 0], size: [2, 6, 2], color: '#79553b' }, { name: 'Tree canopy', position: [0, 7, 0], size: [8, 4, 8], color: '#479754', studs: true }],
        arch: () => [{ name: 'Left pillar', position: [-4, 4, 0], size: [2, 8, 2], color: '#e0d5be' }, { name: 'Right pillar', position: [4, 4, 0], size: [2, 8, 2], color: '#e0d5be' }, { name: 'Arch beam', position: [0, 8.5, 0], size: [10, 1, 2], color: '#e0d5be', studs: true }],
        bounce: () => [{ name: 'Bounce pad', position: [0, .3, 0], size: [5, .6, 5], color: '#a46bff', behavior: 'bounce' }]
    };
    document.querySelectorAll('[data-plugin]').forEach(button => button.onclick = () => { const at = targetPosition(); addParts(prefabs[button.dataset.plugin]().map(part => ({ ...part, position: part.position.map((n, i) => n + (i === 1 ? 0 : at[i])) })), 'Prefab inserted: ' + button.dataset.plugin); $('pluginDialog').close(); });
    $('importPlugin').onclick = () => $('pluginFile').click();
    $('pluginFile').onchange = async () => {
        const file = $('pluginFile').files[0]; if (!file) return;
        try { if (file.size > 512 * 1024) throw new Error('Choose a plugin under 512 KB.'); const plugin = C.plugin(JSON.parse(await file.text())); const at = targetPosition(); addParts(plugin.parts.map(part => ({ ...part, position: part.position.map((n, i) => n + (i === 1 ? 0 : at[i])) })), 'Plugin prefab inserted: ' + plugin.name); $('pluginDialog').close(); }
        catch (error) { log('Plugin rejected: ' + error.message); }
        $('pluginFile').value = '';
    };
    function cast(event) {
        const rect = renderer.domElement.getBoundingClientRect(); mouse.set((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1); raycaster.setFromCamera(mouse, camera);
    }
    renderer.domElement.addEventListener('contextmenu', event => event.preventDefault());
    renderer.domElement.addEventListener('pointerdown', event => {
        viewport.focus();
        if (playing) { if (event.button === 2) { playLook = [event.clientX, event.clientY]; renderer.domElement.setPointerCapture(event.pointerId); } return; }
        if (event.button !== 0) return;
        cast(event); const hits = raycaster.intersectObjects(world.children, true);
        if (!hits.length) { select(null); return; }
        let object = hits[0].object; while (object && !object.userData.partId) object = object.parent;
        if (!object) return; select(object.userData.partId);
        const part = selected(); plane.set(new THREE.Vector3(0, 1, 0), -part.position[1]);
        raycaster.ray.intersectPlane(plane, hitPoint);
        drag = { start: [event.clientX, event.clientY], before: JSON.stringify(project), original: JSON.parse(JSON.stringify(part)), offset: hitPoint.clone().sub(new THREE.Vector3().fromArray(part.position)), moved: false };
        renderer.domElement.setPointerCapture(event.pointerId); controls.enabled = false;
    });
    renderer.domElement.addEventListener('pointermove', event => {
        if (playing) { if (playLook) { cameraYaw -= (event.clientX - playLook[0]) * .006; cameraPitch = Math.max(-.1, Math.min(1.1, cameraPitch + (event.clientY - playLook[1]) * .004)); playLook = [event.clientX, event.clientY]; } return; }
        if (!drag || !selected()) return;
        if (Math.hypot(event.clientX - drag.start[0], event.clientY - drag.start[1]) < 3) return;
        drag.moved = true; const part = selected();
        if (mode === 'move') { cast(event); if (raycaster.ray.intersectPlane(plane, hitPoint)) { const next = hitPoint.clone().sub(drag.offset); part.position = [next.x, part.position[1], next.z].map(n => $('snap').checked ? Math.round(n * 2) / 2 : Math.round(n * 100) / 100); } }
        else if (mode === 'rotate') { const angle = drag.original.rotation[1] + (event.clientX - drag.start[0]) * .6; part.rotation[1] = $('snap').checked ? Math.round(angle / 15) * 15 : angle; }
        else { const scale = Math.max(.15, 1 + (event.clientX - drag.start[0]) * .008); part.size = drag.original.size.map(n => Math.min(512, Math.max(.25, $('snap').checked ? Math.round(n * scale * 4) / 4 : n * scale))); }
        rebuild();
    });
    function finishDrag() { if (drag?.moved) { undo.push(drag.before); if (undo.length > 60) undo.shift(); redo = []; changed('Part ' + mode + ' updated.'); } drag = null; controls.enabled = !playing; playLook = null; }
    renderer.domElement.addEventListener('pointerup', finishDrag); renderer.domElement.addEventListener('pointercancel', finishDrag);
    function makeAvatar() {
        const group = new THREE.Group(); const parts = {};
        function block(name, size, position, color) { const mesh = new THREE.Mesh(new THREE.BoxBufferGeometry(...size), new THREE.MeshStandardMaterial({ color, roughness: .8 })); mesh.position.set(...position); mesh.castShadow = true; group.add(mesh); parts[name] = mesh; }
        block('torso', [1.18, 1.2, .62], [0, 1.85, 0], '#2586ed');
        block('leftArm', [.52, 1.2, .62], [-.87, 1.85, 0], '#d3d3d3'); block('rightArm', [.52, 1.2, .62], [.87, 1.85, 0], '#d3d3d3');
        block('leftLeg', [.55, 1.2, .62], [-.3, .63, 0], '#294b7e'); block('rightLeg', [.55, 1.2, .62], [.3, .63, 0], '#294b7e');
        const head = new THREE.Mesh(window.PolyverseAvatar.headGeometry(), new THREE.MeshStandardMaterial({ color: '#d3d3d3', roughness: .8 })); head.scale.set(.92, .82, .92); head.position.y = 2.775; head.castShadow = true; group.add(head);
        window.PolyverseAvatar.addFace(group, 2.775).scale.set(.92, .82, .92);
        scene.add(group); return { group, parts };
    }
    function boundsFor(data, object) {
        object.updateMatrixWorld(true); const box = new THREE.Box3().setFromObject(object.userData.base);
        return { min: box.min.toArray(), max: box.max.toArray(), behavior: data.behavior, id: data.id };
    }
    function colliders() { return project.parts.filter(part => part.collidable).map(part => boundsFor(part, objects.get(part.id))); }
    function play() {
        if (playing) return; finishDrag(); save(false); editorCamera = { position: camera.position.clone(), target: controls.target.clone() };
        const start = project.parts.find(part => part.shape === 'spawn'); spawn = start ? [start.position[0], start.position[1] + start.size[1] / 2 + .02, start.position[2]] : [0, 5, 0]; checkpoint = spawn.slice();
        player = { position: spawn.slice(), velocity: [0, 0, 0], grounded: false };
        avatar = makeAvatar(); runtimeBodies = project.parts.filter(part => !part.anchored && part.shape !== 'spawn').map(part => ({ data: part, object: objects.get(part.id), velocity: 0 }));
        playing = true; controls.enabled = false; grid.visible = false; selectionBox.visible = false; keys.clear();
        $('projectName').disabled = true;
        $('play').disabled = true; $('stop').disabled = false; $('playHint').hidden = false; $('goalMessage').hidden = true; $('viewportTag').textContent = 'PLAY TEST'; $('selectionLabel').textContent = 'Your changes are safe: Stop restores the editor.'; document.body.classList.add('playing'); viewport.focus(); log('Play started. WASD to move, Space to jump.');
    }
    function stop() {
        if (!playing) return; playing = false; controls.enabled = true; grid.visible = true; keys.clear();
        if (avatar) { scene.remove(avatar.group); avatar.group.traverse(object => { if (object.geometry) object.geometry.dispose(); if (object.material) { if (object.material.map) object.material.map.dispose(); object.material.dispose(); } }); avatar = null; }
        camera.position.copy(editorCamera.position); controls.target.copy(editorCamera.target); controls.update(); runtimeBodies = [];
        $('projectName').disabled = false;
        $('play').disabled = false; $('stop').disabled = true; $('playHint').hidden = true; $('goalMessage').hidden = true; $('viewportTag').textContent = 'EDIT MODE'; document.body.classList.remove('playing'); rebuild(); log('Play stopped. Original parts restored.');
    }
    $('play').onclick = play; $('stop').onclick = stop;
    function resetPlayer() { player.position = checkpoint.slice(); player.velocity = [0, 0, 0]; player.grounded = false; log('Player returned to checkpoint.'); }
    let walkTime = 0;
    function simulate(dt) {
        for (const body of runtimeBodies) {
            const previousBottom = boundsFor(body.data, body.object).min[1]; body.velocity -= 23 * dt; body.object.position.y += body.velocity * dt;
            const box = boundsFor(body.data, body.object);
            for (const part of project.parts) {
                if (part.id === body.data.id || !part.collidable || !part.anchored) continue;
                const ground = boundsFor(part, objects.get(part.id));
                if (body.velocity <= 0 && previousBottom >= ground.max[1] - .1 && C.intersects(box, ground)) { body.object.position.y += ground.max[1] - box.min[1]; body.velocity = 0; break; }
            }
        }
        const x = (keys.has('KeyD') || keys.has('ArrowRight') ? 1 : 0) - (keys.has('KeyA') || keys.has('ArrowLeft') ? 1 : 0);
        const z = (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0) - (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0);
        const dx = x * Math.cos(cameraYaw) + z * Math.sin(cameraYaw), dz = -x * Math.sin(cameraYaw) + z * Math.cos(cameraYaw);
        player = C.stepPlayer(player, { x: dx, z: dz, run: keys.has('ShiftLeft') || keys.has('ShiftRight'), jump: keys.has('Space') }, dt, colliders());
        if (player.touched?.behavior === 'checkpoint') checkpoint = [player.touched.min[0] + (player.touched.max[0] - player.touched.min[0]) / 2, player.touched.max[1] + .02, player.touched.min[2] + (player.touched.max[2] - player.touched.min[2]) / 2];
        if (player.touched?.behavior === 'goal') $('goalMessage').hidden = false;
        if (player.position[1] < -50 || player.touched?.behavior === 'danger') resetPlayer();
        avatar.group.position.fromArray(player.position);
        const moving = Math.hypot(dx, dz) > .01; if (moving) avatar.group.rotation.y = Math.atan2(dx, dz);
        walkTime += dt * (keys.has('ShiftLeft') || keys.has('ShiftRight') ? 13 : 9);
        const pose = C.walkPose(walkTime, moving, player.grounded);
        Object.keys(pose).forEach(name => { avatar.parts[name].rotation.x = pose[name]; });
        const target = new THREE.Vector3(player.position[0], player.position[1] + 1.8, player.position[2]);
        const distance = 11; const desired = target.clone().add(new THREE.Vector3(Math.sin(cameraYaw) * distance * Math.cos(cameraPitch), 3 + Math.sin(cameraPitch) * distance, Math.cos(cameraYaw) * distance * Math.cos(cameraPitch)));
        camera.position.lerp(desired, Math.min(1, dt * 12)); camera.lookAt(target);
    }
    window.addEventListener('keydown', event => {
        const typing = /INPUT|SELECT|TEXTAREA/.test(event.target.tagName);
        if (typing) return;
        if (playing) { if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault(); keys.add(event.code); if (event.code === 'Escape') stop(); return; }
        if ((event.ctrlKey || event.metaKey) && event.code === 'KeyS') { event.preventDefault(); save(); }
        else if ((event.ctrlKey || event.metaKey) && event.code === 'KeyZ') { event.preventDefault(); (event.shiftKey ? $('redo') : $('undo')).click(); }
        else if ((event.ctrlKey || event.metaKey) && event.code === 'KeyD') { event.preventDefault(); $('duplicate').click(); }
        else if (event.code === 'Delete' || event.code === 'Backspace') { event.preventDefault(); $('deletePart').click(); }
        else if (event.code === 'KeyF') focus();
    });
    window.addEventListener('keyup', event => keys.delete(event.code)); window.addEventListener('blur', () => { keys.clear(); playLook = null; });
    window.addEventListener('beforeunload', event => { if (dirty) { event.preventDefault(); event.returnValue = ''; } });
    const resize = () => { const width = viewport.clientWidth, height = viewport.clientHeight; renderer.setSize(width, height, false); camera.aspect = width / Math.max(1, height); camera.updateProjectionMatrix(); };
    new ResizeObserver(resize).observe(viewport); resize();
    try { const saved = localStorage.getItem(STORAGE); if (saved) { project = C.validate(JSON.parse(saved)); log('Your saved local project was restored.'); } else $('saveStatus').textContent = 'New project — save or export'; }
    catch (_) { $('saveStatus').textContent = 'Not saved — export a file'; log('No valid saved project found. Starting with Blue Sky Obby. Export a file to keep a backup.'); }
    rebuild(); controls.update();
    let previous = performance.now(), frameCount = 0, fpsTime = previous, accumulator = 0;
    function frame(now) {
        requestAnimationFrame(frame); const dt = Math.min((now - previous) / 1000, .1); previous = now;
        if (playing) { accumulator += dt; let steps = 0; while (accumulator >= 1 / 60 && steps++ < 6) { simulate(1 / 60); accumulator -= 1 / 60; } } else { accumulator = 0; controls.update(); }
        renderer.render(scene, camera); frameCount++;
        if (now - fpsTime > 1000) { $('fps').textContent = frameCount + ' FPS'; frameCount = 0; fpsTime = now; }
    }
    requestAnimationFrame(frame);
    // Read-only diagnostics for project support and runtime verification.
    window.PolyverseStudio = { snapshot: () => JSON.parse(JSON.stringify(project)), status: () => ({ playing, partCount: project.parts.length, selectedId, playerPosition: player?.position.slice(), playerGrounded: player?.grounded, walkAngle: avatar?.parts.leftLeg.rotation.x, simulatedParts: runtimeBodies.map(body => ({ id: body.data.id, position: body.object.position.toArray() })) }) };
})();
