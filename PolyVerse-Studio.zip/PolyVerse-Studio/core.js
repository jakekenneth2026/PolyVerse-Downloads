/* PolyVerse Studio project format: data only, never executable scripts. */
(function (root) {
    'use strict';
    const SHAPES = ['block', 'sphere', 'cylinder', 'wedge', 'spawn'];
    const BEHAVIORS = ['none', 'bounce', 'checkpoint', 'goal', 'danger'];
    const MAX_PARTS = 500;
    const number = (n, min, max, fallback) => typeof n === 'number' && Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
    const vector = (value, defaults, min, max) => defaults.map((d, i) => number(Array.isArray(value) ? value[i] : undefined, min, max, d));
    const uid = () => root.crypto && root.crypto.randomUUID ? root.crypto.randomUUID() : 'part-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
    function part(input = {}) {
        return { id: typeof input.id === 'string' ? input.id.slice(0, 90) : uid(), name: String(input.name || 'Part').slice(0, 60),
            shape: SHAPES.includes(input.shape) ? input.shape : 'block', position: vector(input.position, [0, 2, 0], -10000, 10000),
            size: vector(input.size, [4, 1, 4], 0.25, 512), rotation: vector(input.rotation, [0, 0, 0], -3600, 3600),
            color: /^#[\da-f]{6}$/i.test(input.color || '') ? input.color : '#2586ed',
            studs: input.studs === true, anchored: input.anchored !== false, collidable: input.collidable !== false,
            behavior: BEHAVIORS.includes(input.behavior) ? input.behavior : 'none' };
    }
    function validate(input) {
        if (!input || input.format !== 'polyverse-studio' || input.version !== 1 || !Array.isArray(input.parts)) throw new Error('Choose a PolyVerse Studio project file (version 1).');
        if (input.parts.length > MAX_PARTS) throw new Error('This version supports up to 500 parts.');
        const seen = new Set();
        const parts = input.parts.map(p => { const clean = part(p); if (seen.has(clean.id)) clean.id = uid(); seen.add(clean.id); return clean; });
        return { format: 'polyverse-studio', version: 1, name: String(input.name || 'Untitled game').slice(0, 80),
            sky: /^#[\da-f]{6}$/i.test(input.sky || '') ? input.sky : '#a5c8eb', parts };
    }
    function empty() { return { format: 'polyverse-studio', version: 1, name: 'My first PolyVerse game', sky: '#a5c8eb', parts: [] }; }
    function starter() {
        const project = empty();
        project.name = 'Blue Sky Obby';
        project.parts.push(part({ name: 'Baseplate', size: [64, 1, 64], position: [0, -0.5, 0], color: '#6e9b67', studs: true }));
        project.parts.push(part({ name: 'Spawn', shape: 'spawn', size: [6, 0.3, 6], position: [0, 0.15, 14], color: '#f1f5fa', behavior: 'checkpoint' }));
        for (let i = 0; i < 8; i++) project.parts.push(part({ name: 'Jump ' + (i + 1), size: [4, 1, 4], position: [(i % 2 ? 3 : -3), 1 + i * 0.7, 7 - i * 5], color: i % 2 ? '#35ade0' : '#2586ed', studs: true }));
        project.parts.push(part({ name: 'Bounce pad', size: [5, 0.5, 5], position: [10, 0.25, 10], color: '#a66aff', behavior: 'bounce' }));
        project.parts.push(part({ name: 'Finish', size: [7, 1, 6], position: [3, 6.6, -34], color: '#ffd15c', studs: true, behavior: 'goal' }));
        return project;
    }
    function intersects(a, b) { return a.min[0] < b.max[0] && a.max[0] > b.min[0] && a.min[1] < b.max[1] && a.max[1] > b.min[1] && a.min[2] < b.max[2] && a.max[2] > b.min[2]; }
    function playerBounds(position) { return { min: [position[0] - .43, position[1], position[2] - .43], max: [position[0] + .43, position[1] + 3.35, position[2] + .43] }; }
    function stepPlayer(state, input, dt, colliders) {
        dt = number(dt, 0, 1 / 30, 1 / 60);
        const speed = input.run ? 14 : 8;
        const length = Math.hypot(input.x || 0, input.z || 0) || 1;
        const velocity = [(input.x || 0) / length * speed, state.velocity[1] - 23 * dt, (input.z || 0) / length * speed];
        if (input.jump && state.grounded) velocity[1] = 9;
        const position = state.position.slice();
        let grounded = false, touched = null;
        for (const axis of [0, 2, 1]) {
            const delta = velocity[axis] * dt;
            position[axis] += delta;
            let box = playerBounds(position);
            for (const collider of colliders) {
                if (!intersects(box, collider)) continue;
                if (axis === 1) {
                    if (delta <= 0) { position[1] = collider.max[1]; grounded = true; touched = collider; }
                    else position[1] = collider.min[1] - 3.35;
                    velocity[1] = 0;
                } else {
                    position[axis] = delta > 0 ? collider.min[axis] - .431 : collider.max[axis] + .431;
                    velocity[axis] = 0;
                }
                box = playerBounds(position);
            }
        }
        if (touched && touched.behavior === 'bounce') { velocity[1] = 15; grounded = false; }
        return { position, velocity, grounded, touched };
    }
    function walkPose(time, moving, grounded) {
        const stride = moving ? Math.sin(time) * (grounded ? 0.5 : 0.12) : 0;
        return { leftLeg: stride, rightLeg: -stride, leftArm: -stride * 0.8, rightArm: stride * 0.8 };
    }
    function plugin(input) {
        if (!input || input.format !== 'polyverse-plugin' || input.version !== 1 || !Array.isArray(input.parts) || input.parts.length > 100) throw new Error('Plugins must be data-only PolyVerse plugin files with at most 100 parts.');
        return { name: String(input.name || 'Imported prefab').slice(0, 60), parts: input.parts.map(p => part({ ...p, id: uid() })) };
    }
    const api = { part, validate, empty, starter, intersects, playerBounds, stepPlayer, walkPose, plugin, uid, MAX_PARTS };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    root.PolyverseStudioCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
